package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.Contact;

@SpringBootApplication
@OpenAPIDefinition(
    info = @Info(
        title = "API de Gestion de Bibliothèque",
        version = "1.0",
        description = "API REST pour la gestion des livres et des auteurs dans une bibliothèque",
        contact = @Contact(
            name = "Support Technique",
            email = "support@bibliotheque.fr"
        )
    )
)
public class LibraryManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);
    }
}