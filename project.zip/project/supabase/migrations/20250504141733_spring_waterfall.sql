-- Insert initial authors
INSERT INTO authors (first_name, last_name, biography) VALUES
('George', 'Orwell', 'English novelist and essayist known for Animal Farm and 1984.'),
('J.K.', 'Rowling', 'British author best known for the Harry Potter series.'),
('Agatha', 'Christie', 'English writer known for her detective novels.'),
('Gabriel', 'García Márquez', 'Colombian novelist known for One Hundred Years of Solitude.');

-- Insert initial books
INSERT INTO books (title, description, isbn, publication_date, author_id) VALUES
('1984', 'A dystopian social science fiction novel', '9780451524935', '1949-06-08', 1),
('Animal Farm', 'An allegorical novella', '9780452284241', '1945-08-17', 1),
('Harry Potter and the Philosopher''s Stone', 'The first novel in the Harry Potter series', '9780747532699', '1997-06-26', 2),
('Harry Potter and the Chamber of Secrets', 'The second novel in the Harry Potter series', '9780747538486', '1998-07-02', 2),
('Murder on the Orient Express', 'Detective novel featuring Hercule Poirot', '9780062693662', '1934-01-01', 3),
('Death on the Nile', 'Mystery novel featuring detective Hercule Poirot', '9780062073556', '1937-11-01', 3),
('One Hundred Years of Solitude', 'A landmark novel in magical realism', '9780060883287', '1967-05-30', 4);