-- Insertion des auteurs initiaux
INSERT INTO authors (first_name, last_name, biography) VALUES
('Victor', 'Hugo', 'Écrivain, poète, dramaturge et homme politique français'),
('Albert', 'Camus', 'Écrivain, philosophe, romancier et dramaturge français'),
('Émile', 'Zola', 'Écrivain et journaliste français'),
('Simone', 'de Beauvoir', 'Philosophe, romancière et essayiste française');

-- Insertion des livres initiaux
INSERT INTO books (title, description, isbn, publication_date, author_id) VALUES
('Les Misérables', 'Roman historique et social français', '9780451524935', '1862-01-01', 1),
('Notre-Dame de Paris', 'Roman historique français', '9780452284241', '1831-01-01', 1),
('L''Étranger', 'Roman existentialiste', '9780747532699', '1942-01-01', 2),
('La Peste', 'Roman allégorique', '9780747538486', '1947-01-01', 2),
('Germinal', 'Roman sur la condition ouvrière', '9780062693662', '1885-01-01', 3),
('Le Deuxième Sexe', 'Essai philosophique féministe', '9780060883287', '1949-01-01', 4);